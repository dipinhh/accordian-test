import { Component, OnInit } from "@angular/core";
import { AppService } from "./app.service";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent implements OnInit{
  collapsing = true;
  faqData :any[] = [];
   constructor(private appService: AppService) { 
   }
  ngOnInit() {
    this.getQuestions();
  }

getQuestions() {
  this.appService.getData().subscribe(res => {
    this.faqData = res;
  });
}
}
