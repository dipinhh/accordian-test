import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { AppService } from './app.service';
import * as datas from '../assets/data/faqs.json';
import { of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      imports:[HttpClientTestingModule],
      providers:[
        {provide: AppService}
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('#getQuestions - should return data containing list of questions', () => {
    const appService = TestBed.inject(AppService)
    spyOn(appService, 'getData').and.returnValue(of(datas));
    component.getQuestions();
    expect(component.faqData).toEqual(datas);
    });
});
