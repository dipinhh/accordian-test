import { trigger, state, style, transition, animate } from "@angular/animations";
import {
  Component,
  ContentChildren,
  Input,
  QueryList
} from "@angular/core";
import {memoize} from 'lodash-es'
import { AccordionItem } from '../directives/accordion-item.directive';

@Component({
  selector: "accordion",
  templateUrl: "./accordion.component.html",
  styleUrls: ["./accordion.component.scss"],
  animations: [
    trigger('contentExpansion', [
      state('expanded', style({height: '*', opacity: 1, visibility: 'visible'})),
      state('collapsed', style({height: '0px', opacity: 0, visibility: 'hidden'})),
      transition('expanded <=> collapsed',
        animate('200ms cubic-bezier(.37,1.04,.68,.98)')),
    ])
  ]
})
export class AccordionComponent {
  expanded = new Set<number>();
  @Input() collapsing = true;
  
  @ContentChildren(AccordionItem) items: QueryList<AccordionItem> | any;

  getToggleState = memoize((index: number) => {
    return this.toggleState.bind(this, index);
  })

  toggleState = (index: number) => {
    if (this.expanded.has(index)) {
      this.expanded.delete(index);
    } else {
      if (this.collapsing) {
        this.expanded.clear();
      }
      this.expanded.add(index);
    }
  };
}
