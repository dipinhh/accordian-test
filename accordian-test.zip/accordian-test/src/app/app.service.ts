import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }
  getData(): Observable<any> {
    return this.http.get<any>('../assets/data/faqs.json').pipe(
      map((data) => data),
      catchError((error) => throwError(error))
    );
  }

}
